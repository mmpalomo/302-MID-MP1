import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, Text, StyleSheet, ScrollView } from 'react-native';

const GoalApp = () => {
  const [goal, setGoal] = useState('');
  const [goalsList, setGoalsList] = useState([]);

  const addGoalHandler = () => {
    if (goal.trim() !== '') {
      const randomColor = getRandomColor();
      setGoalsList([...goalsList, { key: Math.random().toString(), value: goal, color: randomColor }]);
      setGoal('');
    }
  };

  const renderItem = ({ item }) => (
    <View style={{ ...styles.goalItem, backgroundColor: item.color }}>
      <Text style={styles.bullet}>•</Text>
      <Text style={styles.goalText}>{item.value}</Text>
    </View>
  );

  const getRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Enter your wish or goal"
          style={styles.input}
          onChangeText={(text) => setGoal(text)}
          value={goal}
        />
        <Button title="Add" onPress={addGoalHandler} />
      </View>
      <ScrollView>
        <FlatList
          data={goalsList}
          renderItem={renderItem}
          keyExtractor={(item) => item.key}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  input: {
    width: '70%',
    borderBottomColor: 'black',
    borderBottomWidth: 1,
    padding: 10,
  },
  goalItem: {
    padding: 10,
    marginVertical: 5,
    borderColor: 'black',
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  bullet: {
    fontSize: 20,
    marginRight: 10,
  },
  goalText: {
    flex: 1,
    fontSize: 16,
  },
});

export default GoalApp;
